#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <SoftwareSerial.h>
#define VOLTRONIC_USE_WEB 1
#include <VoltronicMAX.h>

SoftwareSerial invSerial(16, 17);
VoltronicMAX inverter(invSerial);
WebServer server(80);

void setup() {
  Serial.begin(115200);
  invSerial.begin(2400);
  inverter.begin(2400);
  inverter.attachWebServer(&server);
  server.begin();
}

void loop() {
  server.handleClient();
}
